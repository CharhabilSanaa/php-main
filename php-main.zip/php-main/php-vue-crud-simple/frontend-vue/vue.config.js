module.exports = {
    devServer: {
        port: 9080
    }
}