CakePHP - Environment Setup - Ubuntu:

https://www.knowledgefactory.net/2021/10/cakephp-environment-setup-ubuntu.html
