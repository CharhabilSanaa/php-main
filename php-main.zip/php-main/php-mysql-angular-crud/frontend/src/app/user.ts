export class User {
    id: string;
    first_name: string;
    last_name: string;
    email_id: string;
    active: boolean;

}